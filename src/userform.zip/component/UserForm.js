import React from 'react'
import Useform from '../Hooks/Useform'
import Validate from '../utils/Validate';
import './UserForm.css'
const UserForm = () => {
   const {handleChange,values,handleSubmit,errors} = Useform(Validate);

   const sendEmail =() =>{};
  return (
    <section className='form-content'>
        <button>Click The Form</button>
         <form className='form' onSubmit={handleSubmit} >
         
            <h1>User Form</h1>
            <div className='form-inputs'>
                <input type='text' 
                onChange={handleChange}
                value={values.username}
                name='username' 
                className='form-input' 
                placeholder='User Name'/>
                {errors.username && <p id='errors'>{errors.username}</p>}
            </div>

            <div className='form-inputs'>
                <input type='email' 
                 onChange={handleChange}
                 value={values.email}
                name='email'
                className='form-input' 
                placeholder='User Email'/>
                {errors.email && <p id='errors'>{errors.email}</p>}
            </div>

            <div className='form-inputs'>
                <input type='number' 
                 onChange={handleChange}
                name='mbl' 
                value={values.mbl}
                className='form-input' 
                placeholder='User Mbl'/>
                {errors.mbl && <p id='errors'>{errors.mbl}</p>}
            </div>

            <div className='form-inputs'>
                <textarea type='text' 
                 onChange={handleChange}
                name='feedback' 
                value={values.feedback}
                className='form-input' 
                placeholder='Type Your FeedBack' cols={30} rows={5}/>
                {errors.feedback && <p id='errors'>{errors.feedback}</p>}
            </div>

            <div className='form-btn'>
                <button type='submit' className='form-submit'>Submit</button>
            </div>

            

        </form>
    </section>
    
  )
}

export default UserForm