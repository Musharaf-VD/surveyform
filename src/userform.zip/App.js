
import './App.css';
import UserForm from './component/UserForm';

function App() {
  return (
    <div className="App">
        <UserForm/>
    </div>
  );
}

export default App;
